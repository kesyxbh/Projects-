# Title: PD1-mediated Modulation of TCR Signaling in Jurkat Cells (Proteomics)

## Abstract (150–200 words)
[Brief background on PD1/TCR, dataset, methods, key findings, significance.]

## Introduction (200–300 words)
- Immune checkpoint PD1 and TCR signaling background.
- Experimental design: Jurkat T cells; Control (TCR only) vs Experimental (TCR+PD1) across timepoints.
- Study objective: Identify proteins/pathways modulated by PD1 activation.

## Methods (300–400 words)
### Data
- Raw protein intensities: tp reordered (1).xlsx
- Metadata: meta_data (1).csv

### Preprocessing
- Use first row as header; select condition/time columns.
- log2(x+1), sample-wise normalization (median or quantile).
- Missing value handling (e.g., per-protein min count filter; impute with sample median when needed).

### Analyses
- EDA: PCA on proteins with <30% missing; clustering of temporal profiles.
- Differential abundance: Control vs PD1 at matched timepoints (linear models / t-test when per-sample data available).
- Time-course: Interaction model (condition × time) to find PD1 effects over time.
- Pathway enrichment: GO/KEGG/Reactome on significant proteins.

### Software
- Python: pandas, numpy, scipy, scikit-learn, statsmodels (optional); matplotlib for plots.

## Results (400–500 words)
### Sample and data QC
- PCA separation by condition/time; replicate consistency (if per-sample data available).
- Missingness profile; normalization effects.

### Differential proteins
- Volcano plots per timepoint; top up/down-regulated proteins with PD1.
- Notable immune signaling nodes (e.g., LCK, ZAP70, LAT, PLCG1, PTPN11) if detected.

### Pathway insights
- Enriched pathways related to TCR signaling, MAPK, PI3K-AKT, NF-κB, apoptosis, metabolism.
- Temporal dynamics of key proteins/pathways.

## Conclusions (150–200 words)
- Summary of PD1’s modulatory effects on TCR signaling in Jurkat proteome.
- Limitations: aggregation vs per-sample availability, missingness, batch effects.
- Future work: phosphoproteomics, validation, perturbation experiments.

## References
[Insert 5–8 key papers and resources.]

## GitHub
- Repository URL: [to be added]
