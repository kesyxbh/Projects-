# RUN_INSTRUCTIONS_WINDOWS

目标路径：`E:\25-26 summer\research\project`

## 步骤
1) 把本压缩包解压到 `E:\`，会得到：
   `E:\25-26 summer\research\project\`

2) 将数据文件放到项目根目录或 `data\` 目录：
   - `tp reordered (1).xlsx`
   - `meta_data (1).csv`

3) 在此目录打开 PowerShell 或 CMD，创建并激活虚拟环境：
```
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

4) 运行脚本（或用 Jupyter 打开 Notebook）：
```
python PD1_TCR_proteomics_pipeline.py
```
或
```
jupyter notebook
# 打开 PD1_TCR_proteomics_analysis.ipynb，依次执行各单元
```

## 输出
- 结果会生成在 `outputs\` 文件夹（差异分析表、log2FC、PCA等）。

## 常见问题
- 若找不到数据文件，请确认文件名与路径（含空格）是否一致。
- 如果 Notebook 报找不到脚本，确保 `PD1_TCR_proteomics_pipeline.py` 与 Notebook 在同一目录。
