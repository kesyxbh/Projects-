#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PD1–TCR Proteomics Analysis Pipeline (Jurkat)
- Modes:
  A) Per-sample: proteomics columns match metadata['sample_id'] -> statistical tests available.
  B) Aggregated: only condition/time aggregated columns -> descriptive log2FC.
Dependencies: pandas, numpy, scipy, scikit-learn, matplotlib (offline).
"""

from typing import List, Tuple, Optional
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.impute import KNNImputer
from sklearn.preprocessing import StandardScaler
from scipy import stats
import matplotlib.pyplot as plt
import json

# ---------------- IO & Utilities ----------------

def load_metadata(meta_path: Path) -> pd.DataFrame:
    meta = pd.read_csv(meta_path)
    meta.columns = [c.strip().lower() for c in meta.columns]
    return meta

def load_proteomics_excel(xlsx_path: Path) -> pd.DataFrame:
    import pandas as pd
    raw = pd.read_excel(xlsx_path, header=None)
    first_row = raw.iloc[0].astype(str).tolist()
    n_texty = sum([1 for x in first_row if any(k in x.lower()
                  for k in ["protein","entry","gene","reporter","ctrl","pd-1","pd1","min","h"])])
    if n_texty >= 3:
        df = raw.iloc[1:].copy()
        df.columns = first_row
    else:
        df = pd.read_excel(xlsx_path)
    df = df.loc[:, ~df.columns.astype(str).str.lower().eq("nan")]
    return df

def guess_id_column(df: pd.DataFrame) -> Optional[str]:
    for c in ["Gene","gene","Entry Name","Entry","EntryName","Protein ID","Protein","Accession","UniProt","uniprot"]:
        if c in df.columns:
            return c
    return df.columns[0] if len(df.columns) else None

def detect_sample_columns_from_meta(df: pd.DataFrame, meta: pd.DataFrame) -> List[str]:
    sample_col = None
    for c in ["sample_id","sample","sampleid","run","file","filename"]:
        if c in meta.columns:
            sample_col = c
            break
    if sample_col is None:
        return []
    meta_ids = set(meta[sample_col].astype(str))
    return [c for c in df.columns if str(c) in meta_ids]

def detect_condition_columns(df: pd.DataFrame) -> List[str]:
    keys = ["pd1","pd-1","tcs","ctrl","unstimulated","min","h","pd-l1","pdl1","reporter"]
    return [c for c in df.columns if any(k in str(c).lower() for k in keys)]

# ---------------- Preprocessing ----------------

def log2_transform(X: pd.DataFrame) -> pd.DataFrame:
    return np.log2(X.astype(float) + 1.0)

def median_normalize(X: pd.DataFrame) -> pd.DataFrame:
    med = X.median(axis=0, skipna=True)
    return X.subtract(med, axis=1)

def filter_missing_by_row(X: pd.DataFrame, max_missing_frac: float=0.5) -> pd.DataFrame:
    keep = X.isna().mean(axis=1) <= max_missing_frac
    return X.loc[keep]

def impute_knn(X: pd.DataFrame, n_neighbors: int=5) -> pd.DataFrame:
    imputer = KNNImputer(n_neighbors=n_neighbors)
    values = imputer.fit_transform(X)
    return pd.DataFrame(values, index=X.index, columns=X.columns)

# ---------------- Reshaping ----------------

def to_long_with_meta(df: pd.DataFrame, id_col: str, sample_cols: List[str], meta: pd.DataFrame) -> pd.DataFrame:
    long = df.melt(id_vars=[id_col], value_vars=sample_cols,
                   var_name="sample_id", value_name="intensity")
    long["sample_id"] = long["sample_id"].astype(str)
    m = meta.copy()
    if "sample_id" not in m.columns:
        for c in ["sample","sampleid","run","file","filename"]:
            if c in m.columns:
                m = m.rename(columns={c:"sample_id"})
                break
    return long.merge(m, on="sample_id", how="left")

# ---------------- QC & PCA ----------------

def pca_plot(X: pd.DataFrame, labels: Optional[pd.Series]=None, title: str="PCA"):
    scaler = StandardScaler(with_mean=True, with_std=True)
    Xs = scaler.fit_transform(X.fillna(X.median()))
    pca = PCA(n_components=2, random_state=0)
    comp = pca.fit_transform(Xs)
    fig, ax = plt.subplots(figsize=(6,5))
    ax.scatter(comp[:,0], comp[:,1])
    if labels is not None:
        for i, txt in enumerate(labels.astype(str).tolist()):
            ax.annotate(txt, (comp[i,0], comp[i,1]), fontsize=8)
    ax.set_xlabel("PC1"); ax.set_ylabel("PC2"); ax.set_title(title)
    plt.show()

# ---------------- Differential (per-sample) ----------------

def per_timepoint_ttest(long: pd.DataFrame, id_col: str, time_value: str,
                        condition_col: str="condition") -> pd.DataFrame:
    sub = long[long["time"].astype(str).str.lower().eq(str(time_value).lower())].copy()
    sub["cond_bin"] = sub[condition_col].astype(str).str.lower()
    def map_cond(x):
        x = x.replace(" ","").replace("-","").replace("_","")
        if "pd1" in x or "pdl1" in x or "pd-1" in x or x=="pd1":
            return "PD1"
        if "control" in x or "ctrl" in x:
            return "CTRL"
        return x.upper()
    sub["group"] = sub["cond_bin"].map(map_cond)

    out = []
    for pid, g in sub.groupby(id_col):
        g1 = g[g["group"]=="PD1"]["intensity"].dropna()
        g0 = g[g["group"]=="CTRL"]["intensity"].dropna()
        if len(g1) >= 2 and len(g0) >= 2:
            t, p = stats.ttest_ind(g1, g0, equal_var=False, nan_policy="omit")
            log2fc = g1.mean() - g0.mean()
            out.append((pid, log2fc, p, len(g1), len(g0)))
    res = pd.DataFrame(out, columns=[id_col, "log2FC_PD1_vs_CTRL", "pvalue", "n_PD1", "n_CTRL"])
    if len(res):
        res = res.sort_values("pvalue")
        m = len(res); ranks = np.arange(1, m+1)
        res["FDR"] = (res["pvalue"] * m / ranks).clip(upper=1.0)
    return res

# ---------------- Aggregated-mode ----------------

def parse_condition_time_from_col(colname: str) -> Tuple[str, str]:
    s = str(colname).lower()
    cond = "PD1" if any(k in s for k in ["pd-l1","pdl1","pd1","pd-1"]) else "CTRL"
    if "unstimulated" in s or "0 min" in s or "0min" in s: t = "0 min"
    elif "5" in s and "min" in s: t = "5 min"
    elif "20" in s and "min" in s: t = "20 min"
    elif "4h" in s or "4 h" in s or "4hour" in s: t = "4 h"
    else: t = "NA"
    return cond, t

def aggregated_long(df: pd.DataFrame, id_col: str, cond_cols: List[str]) -> pd.DataFrame:
    parts = []
    for c in cond_cols:
        cond, tm = parse_condition_time_from_col(c)
        part = df[[id_col, c]].rename(columns={c:"intensity"})
        part["condition"] = cond; part["time"] = tm; part["sample_id"] = c
        parts.append(part)
    return pd.concat(parts, axis=0, ignore_index=True)

def aggregated_fold_changes(df: pd.DataFrame, id_col: str, cond_cols: List[str]) -> pd.DataFrame:
    long = aggregated_long(df, id_col, cond_cols)
    long["intensity"] = np.log2(long["intensity"].astype(float) + 1.0)
    out = []
    for t, g in long.groupby("time"):
        if t == "NA": continue
        mean_pd1 = g[g["condition"]=="PD1"].groupby(id_col)["intensity"].mean()
        mean_ctrl = g[g["condition"]=="CTRL"].groupby(id_col)["intensity"].mean()
        joined = pd.concat([mean_pd1.rename("PD1"), mean_ctrl.rename("CTRL")], axis=1)
        joined["log2FC_PD1_vs_CTRL"] = joined["PD1"] - joined["CTRL"]
        joined["time"] = t
        out.append(joined.reset_index())
    return pd.concat(out, axis=0, ignore_index=True) if out else pd.DataFrame(
        columns=[id_col,"PD1","CTRL","log2FC_PD1_vs_CTRL","time"]
    )

# ---------------- Save helpers ----------------

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def save_table(df: pd.DataFrame, path: Path):
    df.to_csv(path, index=False)

# ---------------- Main driver ----------------

def run_pipeline(prot_path: Path, meta_path: Path, outdir: Path, max_missing_frac: float=0.5):
    ensure_dir(outdir)

    meta = load_metadata(meta_path)
    df = load_proteomics_excel(prot_path)
    id_col = guess_id_column(df)
    if id_col is None:
        raise ValueError("Could not infer an ID column from the proteomics table.")

    sample_cols = detect_sample_columns_from_meta(df, meta)
    cond_cols = detect_condition_columns(df)

    # Save columns overview
    save_table(pd.DataFrame({"column": df.columns}), outdir / "proteomics_columns.csv")

    if sample_cols:
        mode = "per-sample"
        X = df[sample_cols].apply(pd.to_numeric, errors="coerce")
        X = median_normalize(log2_transform(X))
        X[id_col] = df[id_col].values
        Xf = filter_missing_by_row(X.drop(columns=[id_col]), max_missing_frac=max_missing_frac)
        X = X.loc[Xf.index]

        long = to_long_with_meta(pd.concat([df[[id_col]], X.drop(columns=[id_col])], axis=1),
                                 id_col, X.drop(columns=[id_col]).columns.tolist(), meta)
        save_table(long.head(1000), outdir / "long_with_meta_preview.csv")

        # PCA
        pivot = long.pivot_table(index="sample_id", columns=id_col, values="intensity", aggfunc="mean")
        pca_plot(pivot, labels=long.drop_duplicates("sample_id")["time"], title="PCA (per-sample)")

        # Per-timepoint DA
        results = []
        for t in sorted(long["time"].dropna().astype(str).unique()):
            res = per_timepoint_ttest(long, id_col=id_col, time_value=t)
            if len(res):
                res["time"] = t
                save_table(res, outdir / f"DA_per_time_{t.replace(' ','_')}.csv")
                results.append(res)
        if results:
            all_res = pd.concat(results, axis=0, ignore_index=True)
            save_table(all_res, outdir / "DA_all_times.csv")

    elif cond_cols:
        mode = "aggregated"
        X = df[cond_cols].apply(pd.to_numeric, errors="coerce")
        X = median_normalize(log2_transform(X))
        miss = X.isna().mean().rename("missing_fraction").reset_index().rename(columns={"index":"column"})
        save_table(miss, outdir / "missingness_by_column.csv")

        pca_plot(X.T, labels=pd.Series(cond_cols), title="PCA (aggregated columns)")
        fc = aggregated_fold_changes(df, id_col=id_col, cond_cols=cond_cols)
        save_table(fc, outdir / "aggregated_log2FC_by_time.csv")
    else:
        mode = "unknown"
        raise ValueError("Could not find per-sample columns or recognizable condition/time columns.")

    with open(outdir / "run_metadata.json", "w", encoding="utf-8") as f:
        json.dump({"mode": mode, "id_col": id_col,
                   "prot_path": str(prot_path), "meta_path": str(meta_path)}, f, ensure_ascii=False, indent=2)
    print(f"Pipeline finished in [{mode}] mode. Outputs written to: {outdir}")

if __name__ == "__main__":
    # 默认相对路径：把数据放在项目根目录或 data/ 下，按需要修改下面的路径。
    prot_path = Path("tp reordered (1).xlsx") if Path("tp reordered (1).xlsx").exists() else Path("data") / "tp reordered (1).xlsx"
    meta_path = Path("meta_data (1).csv")      if Path("meta_data (1).csv").exists()      else Path("data") / "meta_data (1).csv"
    outdir = Path("outputs")
    run_pipeline(prot_path, meta_path, outdir)
